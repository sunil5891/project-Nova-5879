import os
import logging
from typing import List
import uuid
import datetime
import asyncio
# import spacy
from openai import OpenAI  
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from semantic_kernel import Kernel  
from semantic_kernel.agents import AzureAIAgent, AzureAIAgentSettings  
from azure.ai.agents import AIProjectsClient  
from typing import List, Dict, Any
from azure.storage.blob import BlobServiceClient
from semantic_kernel.connectors.ai.open_ai import OpenAIChatCompletion  
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion#
from azure.ai.projects import AIProjectsClient
from azure.ai.agents import AgentRunRequest, AgentRunResult
from semantic_kernel import Kernel
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from semantic_kernel.memory import SemanticTextMemory, VolatileMemoryStore

# ===================================================
# Configuration – replace with your actual values
# ===================================================
AZURE_BLOB_CONNECTION_STRING = os.getenv("AZURE_BLOB_CONNECTION_STRING")
BLOB_CONTAINER = os.getenv("AZURE_BLOB_CONTAINER")

AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")

AZURE_FOUNDY_PROJECT_ENDPOINT = os.getenv("AZURE_FOUNDY_PROJECT_ENDPOINT")
AZURE_FOUNDY_API_KEY = os.getenv("AZURE_FOUNDY_API_KEY")

# COMPLIANCE_RULES = ["GDPR", "Confidentiality", "NDA", "Data Protection"]?
# Initialize Semantic Kernel
kernel = Kernel()
kernel.add_service(
    AzureChatCompletion(
        service_id="gpt-service",
        deployment_name=AZURE_OPENAI_DEPLOYMENT,
        endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=None  # Uses DefaultAzureCredential if not given
    )
)


#  Initialize memory (RAG)
memory = SemanticTextMemory(VolatileMemoryStore(), kernel.embeddings)
kernel.memory = memory

# Initialize Azure Blob Client
blob_client = BlobServiceClient.from_connection_string(AZURE_BLOB_CONNECTION_STRING)
container_client = blob_client.get_container_client(BLOB_CONTAINER)

# -----------------------------------------------------
# 3️⃣ AGENT 1 — Document Ingestion Agent
# -----------------------------------------------------
@kernel_function(name="document_ingestion_agent", description="Ingest and chunk documents into semantic memory.")
async def document_ingestion_agent() -> str:
    """Reads all text blobs from container, stores semantic chunks into memory."""
    print("📥 Ingesting documents from blob storage...")
    async for blob in container_client.list_blobs():
        data = container_client.download_blob(blob.name).readall().decode("utf-8")
        await kernel.memory.save_information("contract_kb", data, id=blob.name)
    return "✅ Documents ingested and indexed in semantic memory."

# -----------------------------------------------------
# 4️⃣ AGENT 2 — Clause Extraction Agent
# -----------------------------------------------------
@kernel_function(name="clause_extraction_agent", description="Extract key contractual clauses from text.")
async def clause_extraction_agent(document_text: str) -> str:
    prompt = f"""
    You are a legal clause extraction assistant.
    Extract key clauses such as:
      - Payment terms
      - Liability
      - Termination
      - Confidentiality
      - Indemnity
    Present results in structured JSON with clause type and clause text.

    Document:
    {document_text}
    """
    response = await kernel.invoke_prompt(prompt, service_id="gpt-service")
    return response

# -----------------------------------------------------
# 5️⃣ AGENT 3 — Compliance Validation Agent
# -----------------------------------------------------
@kernel_function(name="compliance_validation_agent", description="Validate extracted clauses against compliance rules.")
async def compliance_validation_agent(extracted_clauses: str) -> str:
    compliance_rules = """
    1. Liability should be mutual and capped.
    2. Payment terms should not exceed 60 days.
    3. Confidentiality clauses must reference data protection compliance.
    4. Termination notice should be minimum 30 days.
    """
    prompt = f"""
    You are a compliance validator.
    Compare the following extracted clauses with these compliance rules:
    {compliance_rules}

    Clauses:
    {extracted_clauses}

    Output: Clearly state which clauses are COMPLIANT, NON-COMPLIANT, and SUGGESTED REMEDIATIONS.
    """
    result = await kernel.invoke_prompt(prompt, service_id="gpt-service")
    return result

# Register all as dynamic agents
kernel.add_function(document_ingestion_agent)
kernel.add_function(clause_extraction_agent)
kernel.add_function(compliance_validation_agent)

# -----------------------------------------------------
# 6️⃣ ORCHESTRATOR — Flow Control
# -----------------------------------------------------
async def orchestrate():
    print("\n🚀 Starting contract compliance pipeline...")

    # Step 1: Ingest documents from blob
    await kernel.invoke("document_ingestion_agent")

    # Step 2: Retrieve all docs from memory for clause extraction
    search_results = await kernel.memory.search("contract_kb", "contract", limit=2)
    document_texts = "\n\n".join([r.text for r in search_results])

    # Step 3: Extract clauses
    extracted = await kernel.invoke("clause_extraction_agent", document_texts)

    # Step 4: Validate for compliance
    validated = await kernel.invoke("compliance_validation_agent", str(extracted))

    print("\n✅ COMPLIANCE VALIDATION REPORT:\n")
    print(validated)

# -----------------------------------------------------
# 7️⃣ MAIN
# -----------------------------------------------------
async def main():
    await orchestrate()

if __name__ == "__main__":
    asyncio.run(main())